//
//  ViewController.swift
//  proyectoFinal_iOS
//
//  Created by Cristian Bahamondes on 14-06-22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("Hello World")
    }


}

